#@header-start
#@name ping
#@desc �鿴�����Ƿ�����
#@input {name:"ping",default:"",type:"String",option:"yes",detail:"������IP"}
#@output {name:"ping",file:"ping",type:"command",scriptdesc:"����ָ��",modifyStat:"false", isModify:"false"}
#@auth {authcode:"12345678912345613BD6605334F587|MEQCILCokaC0EVJXclSWjEZJTUFNi7O5zT/r97yd8Rc1uG2RAiA6lh3lzvsoX5A9Z77E08Oaq3m+US6jDyblSD0Qj3Ve9Q==",alg:"SM3withSM2",publicKey:"MFkwEwYHKoZIzj0CAQYIKoEcz1UBgi0DQgAEVEJ/Z+JXb4vbt3eXHuln8GZBrrkYuzIYkfmr9jegT0tQCUj5wHB77j1Hq0qutlQg6aPSX2xPetxWpdzuxtwzBQ=="}
#@header-end
#@body-start
#@body-end